package com.stripe.stripepayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripepaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
